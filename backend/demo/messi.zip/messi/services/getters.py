from ..models import *
from rest_framework import status
from ..serializers import *

def user_journeys_api(email):
    try:
        user = User.objects.prefetch_related('journeys').get(email=email)
        journeys = user.journeys.all()
        serializer = JourneySerializer(journeys, many=True)
        return {'data': serializer.data, 'message': 'All journeys of a retrieved successfully'}, status.HTTP_200_OK
    except User.DoesNotExist:
        return {'error': 'User does not exist'}, status.HTTP_404_NOT_FOUND
