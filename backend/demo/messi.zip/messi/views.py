from django.shortcuts import render, HttpResponse
from django.http import JsonResponse
from rest_framework.decorators import api_view
from rest_framework import status

from .models import *
from .serializers import *

from .services.getters import *


@api_view(['GET'])
def users_journeys(request, email):
    print(email)
    result, status_code = user_journeys_api(email)
    return JsonResponse(result, status=status_code)