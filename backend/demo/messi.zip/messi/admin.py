from django.contrib import admin
from .models import User, Journey, City, Business, Planning, Event

admin.site.register(User)
admin.site.register(Journey)
admin.site.register(City)
admin.site.register(Business)
admin.site.register(Planning)
admin.site.register(Event)

